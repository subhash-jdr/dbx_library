package com.appflowretry.appflowretry;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppflowretryApplication {

	public static void main(String[] args) {
		SpringApplication.run(AppflowretryApplication.class, args);
	}

}
