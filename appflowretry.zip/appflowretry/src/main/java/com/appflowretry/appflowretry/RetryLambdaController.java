package com.appflowretry.appflowretry;

import java.util.Map;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.amazonaws.services.lambda.AWSLambda;
import com.amazonaws.services.lambda.AWSLambdaClientBuilder;
import com.amazonaws.services.lambda.model.InvokeRequest;
import com.amazonaws.services.lambda.model.InvokeResult;

@RestController
public class RetryLambdaController {

    // @PostMapping("/retry")
    // public String triggeredLambda(@RequestBody String data){
    //     return "Received and processed data: " + data.get("function_name");
    // }


    @PostMapping("/invoke-lambda")
    public String triggeredLambda(@RequestBody Map<String, Object> requestBody){
        String functionName = (String) requestBody.get("function_name");
        String sourceLocation = (String) requestBody.get("source_location");
        String targetLocation = (String) requestBody.get("target_location");

        // Create an instance of the AWS Lambda client
        AWSLambda lambda = AWSLambdaClientBuilder.standard().build();

        // Create an InvokeRequest with the function name and payload
        InvokeRequest request = new InvokeRequest()
                .withFunctionName(functionName)
                .withPayload("{\"source_location\":\""+sourceLocation+"\",\"target_location\":\""+targetLocation+"\"}");

        // Invoke the Lambda function
        InvokeResult result = lambda.invoke(request);
        return "Processed the lambda "+ result;
        // return "Received and processed data: " + "{\"source_location\":\""+sourceLocation+"\",\"target_location\":\""+targetLocation+"\"}";
    }
}
